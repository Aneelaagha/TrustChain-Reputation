import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Shield, Zap, UserCheck, ArrowRight } from 'lucide-react';
import { motion } from 'motion/react';

export default function Landing() {
  const [email, setEmail] = useState('');
  const [name, setName] = useState('');
  const navigate = useNavigate();

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    // In a real app, we'd authenticate here
    navigate('/dashboard');
  };

  return (
    <div className="min-h-screen flex flex-col md:flex-row">
      {/* Left Side: Brand & Stats */}
      <div className="flex-1 bg-brand p-8 md:p-16 flex flex-col justify-between text-white">
        <div>
          <div className="flex items-center gap-2 mb-12">
            <div className="w-10 h-10 bg-white rounded-lg flex items-center justify-center">
              <Shield className="text-brand w-6 h-6" />
            </div>
            <span className="text-2xl font-bold tracking-tight">TrustChain</span>
          </div>
          
          <div className="max-w-xl">
            <h1 className="text-5xl md:text-7xl font-bold leading-tight mb-8">
              Financial identity for the invisible.
            </h1>
            <p className="text-xl md:text-2xl text-white/80 mb-12 leading-relaxed">
              1.4 billion adults have no credit score. TrustChain changes that by building reputation from the ground up.
            </p>
            
            <div className="space-y-6">
              <div className="flex items-start gap-4">
                <div className="mt-1 bg-white/10 p-2 rounded-lg">
                  <Zap className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-semibold text-lg">Alternative data signals</h3>
                  <p className="text-white/60">Rent, utilities, and mobile data turned into trust.</p>
                </div>
              </div>
              
              <div className="flex items-start gap-4">
                <div className="mt-1 bg-white/10 p-2 rounded-lg">
                  <Shield className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-semibold text-lg">Graph trust propagation</h3>
                  <p className="text-white/60">A network-based score modeled on mathematical trust.</p>
                </div>
              </div>
              
              <div className="flex items-start gap-4">
                <div className="mt-1 bg-white/10 p-2 rounded-lg">
                  <UserCheck className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-semibold text-lg">Portable & user-owned</h3>
                  <p className="text-white/60">Your reputation travels with you, anywhere in the world.</p>
                </div>
              </div>
            </div>
          </div>
        </div>
        
        <div className="mt-12 pt-12 border-t border-white/10">
          <p className="text-sm text-white/40 uppercase tracking-widest font-semibold">
            Empowering the unbanked globally
          </p>
        </div>
      </div>

      {/* Right Side: Login Card */}
      <div className="flex-1 bg-[#F8F9FA] flex items-center justify-center p-8">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="w-full max-w-md"
        >
          <div className="bg-white border border-[#E5E7EB] rounded-[24px] p-8 md:p-12">
            <h2 className="text-3xl font-bold mb-2">Welcome back</h2>
            <p className="text-gray-500 mb-8">Enter your details to access your trust profile.</p>
            
            <form onSubmit={handleLogin} className="space-y-6">
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">Full Name</label>
                <input 
                  type="text" 
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="John Doe"
                  className="w-full px-4 py-3 rounded-lg border border-[#E5E7EB] focus:ring-2 focus:ring-brand focus:border-transparent outline-none transition-all"
                />
              </div>
              
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">Email Address</label>
                <input 
                  type="email" 
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="john@example.com"
                  className="w-full px-4 py-3 rounded-lg border border-[#E5E7EB] focus:ring-2 focus:ring-brand focus:border-transparent outline-none transition-all"
                />
              </div>
              
              <button type="submit" className="w-full btn-primary flex items-center justify-center gap-2 group">
                Get Started
                <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </button>
            </form>
            
            <p className="mt-8 text-center text-sm text-gray-500">
              New to TrustChain? <a href="#" className="text-brand font-semibold hover:underline">Create an account</a>
            </p>
          </div>
        </motion.div>
      </div>
    </div>
  );
}
