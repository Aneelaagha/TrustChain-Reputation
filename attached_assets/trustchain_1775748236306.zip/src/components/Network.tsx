import React, { useEffect, useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Shield, ArrowLeft, Users, Globe, Trophy, Info } from 'lucide-react';
import * as d3 from 'd3';

interface Node extends d3.SimulationNodeDatum {
  id: string;
  name: string;
  score: number;
  vouchCount: number;
  tier: 'Good' | 'Fair' | 'Building';
}

interface Link extends d3.SimulationLinkDatum<Node> {
  source: string | Node;
  target: string | Node;
}

const NODES: Node[] = [
  { id: '1', name: 'You', score: 742, vouchCount: 12, tier: 'Good' },
  { id: '2', name: 'Amara K.', score: 780, vouchCount: 8, tier: 'Good' },
  { id: '3', name: 'David O.', score: 620, vouchCount: 5, tier: 'Fair' },
  { id: '4', name: 'Chen W.', score: 810, vouchCount: 15, tier: 'Good' },
  { id: '5', name: 'Elena R.', score: 540, vouchCount: 3, tier: 'Building' },
  { id: '6', name: 'Kofi B.', score: 710, vouchCount: 7, tier: 'Good' },
  { id: '7', name: 'Sarah L.', score: 690, vouchCount: 6, tier: 'Fair' },
  { id: '8', name: 'Miguel P.', score: 590, vouchCount: 4, tier: 'Fair' },
  { id: '9', name: 'Aisha M.', score: 830, vouchCount: 20, tier: 'Good' },
  { id: '10', name: 'Liam J.', score: 480, vouchCount: 2, tier: 'Building' },
];

const LINKS: Link[] = [
  { source: '1', target: '2' },
  { source: '1', target: '3' },
  { source: '1', target: '4' },
  { source: '2', target: '4' },
  { source: '3', target: '5' },
  { source: '4', target: '6' },
  { source: '6', target: '7' },
  { source: '7', target: '8' },
  { source: '4', target: '9' },
  { source: '5', target: '10' },
  { source: '9', target: '2' },
  { source: '8', target: '1' },
];

export default function Network() {
  const navigate = useNavigate();
  const svgRef = useRef<SVGSVGElement>(null);
  const [hoveredNode, setHoveredNode] = useState<Node | null>(null);
  const [tooltipPos, setTooltipPos] = useState({ x: 0, y: 0 });

  useEffect(() => {
    if (!svgRef.current) return;

    const width = window.innerWidth;
    const height = window.innerHeight;

    const svg = d3.select(svgRef.current)
      .attr('width', width)
      .attr('height', height);

    svg.selectAll('*').remove();

    const simulation = d3.forceSimulation<Node>(NODES)
      .force('link', d3.forceLink<Node, Link>(LINKS).id(d => d.id).distance(150))
      .force('charge', d3.forceManyBody().strength(-500))
      .force('center', d3.forceCenter(width / 2, height / 2))
      .force('collision', d3.forceCollide().radius(60));

    const link = svg.append('g')
      .selectAll('line')
      .data(LINKS)
      .enter().append('line')
      .attr('stroke', '#ffffff20')
      .attr('stroke-width', 1);

    const node = svg.append('g')
      .selectAll('g')
      .data(NODES)
      .enter().append('g')
      .attr('cursor', 'pointer')
      .on('mouseover', (event, d) => {
        setHoveredNode(d);
        setTooltipPos({ x: event.pageX, y: event.pageY });
      })
      .on('mouseout', () => setHoveredNode(null))
      .call(d3.drag<SVGGElement, Node>()
        .on('start', dragstarted)
        .on('drag', dragged)
        .on('end', dragended) as any);

    node.append('circle')
      .attr('r', d => d.id === '1' ? 24 : 18)
      .attr('fill', d => {
        if (d.tier === 'Good') return '#1D9E75';
        if (d.tier === 'Fair') return '#BA7517';
        return '#D85A30';
      })
      .attr('stroke', '#fff')
      .attr('stroke-width', d => d.id === '1' ? 3 : 0);

    node.append('text')
      .text(d => d.name.split(' ')[0])
      .attr('dy', 35)
      .attr('text-anchor', 'middle')
      .attr('fill', '#fff')
      .attr('font-size', '12px')
      .attr('font-weight', '500');

    simulation.on('tick', () => {
      link
        .attr('x1', d => (d.source as Node).x!)
        .attr('y1', d => (d.source as Node).y!)
        .attr('x2', d => (d.target as Node).x!)
        .attr('y2', d => (d.target as Node).y!);

      node.attr('transform', d => `translate(${d.x},${d.y})`);
    });

    function dragstarted(event: any) {
      if (!event.active) simulation.alphaTarget(0.3).restart();
      event.subject.fx = event.subject.x;
      event.subject.fy = event.subject.y;
    }

    function dragged(event: any) {
      event.subject.fx = event.x;
      event.subject.fy = event.y;
    }

    function dragended(event: any) {
      if (!event.active) simulation.alphaTarget(0);
      event.subject.fx = null;
      event.subject.fy = null;
    }

    return () => simulation.stop();
  }, []);

  return (
    <div className="h-screen w-screen bg-[#0f1117] overflow-hidden relative font-sans">
      {/* Top Bar Overlay */}
      <div className="absolute top-0 left-0 right-0 z-20 bg-black/40 backdrop-blur-md border-b border-white/10 px-6 py-4">
        <div className="max-w-7xl mx-auto flex justify-between items-center">
          <div className="flex items-center gap-6">
            <button 
              onClick={() => navigate('/dashboard')}
              className="text-white/60 hover:text-white transition-colors flex items-center gap-2"
            >
              <ArrowLeft className="w-5 h-5" />
              <span className="hidden sm:inline font-medium">Back to Dashboard</span>
            </button>
            <div className="h-6 w-[1px] bg-white/10 hidden sm:block"></div>
            <div className="hidden sm:flex items-center gap-8">
              <div className="flex items-center gap-2">
                <Users className="w-4 h-4 text-brand" />
                <span className="text-white/40 text-xs uppercase tracking-widest font-bold">Total Users</span>
                <span className="text-white font-bold">1,248</span>
              </div>
              <div className="flex items-center gap-2">
                <Globe className="w-4 h-4 text-brand" />
                <span className="text-white/40 text-xs uppercase tracking-widest font-bold">Avg Score</span>
                <span className="text-white font-bold">682</span>
              </div>
              <div className="flex items-center gap-2">
                <Trophy className="w-4 h-4 text-brand" />
                <span className="text-white/40 text-xs uppercase tracking-widest font-bold">Your Rank</span>
                <span className="text-white font-bold">#142</span>
              </div>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Shield className="text-brand w-6 h-6" />
            <span className="text-white font-bold tracking-tight">TrustChain</span>
          </div>
        </div>
      </div>

      {/* Title Overlay */}
      <div className="absolute top-24 left-8 z-10 pointer-events-none">
        <h1 className="text-white text-4xl font-bold mb-1">Trust Network</h1>
        <p className="text-white/40 text-lg">Your financial reputation graph</p>
      </div>

      {/* Legend */}
      <div className="absolute bottom-8 left-8 z-10 bg-black/60 backdrop-blur-md border border-white/10 p-4 rounded-xl space-y-3">
        <div className="flex items-center gap-3">
          <div className="w-3 h-3 rounded-full bg-[#1D9E75]"></div>
          <span className="text-white/80 text-sm font-medium">Good (700+)</span>
        </div>
        <div className="flex items-center gap-3">
          <div className="w-3 h-3 rounded-full bg-[#BA7517]"></div>
          <span className="text-white/80 text-sm font-medium">Fair (580–699)</span>
        </div>
        <div className="flex items-center gap-3">
          <div className="w-3 h-3 rounded-full bg-[#D85A30]"></div>
          <span className="text-white/80 text-sm font-medium">Building (&lt;580)</span>
        </div>
      </div>

      {/* Graph Canvas */}
      <svg ref={svgRef} className="w-full h-full" />

      {/* Node Tooltip */}
      {hoveredNode && (
        <div 
          className="absolute z-30 pointer-events-none"
          style={{ 
            left: tooltipPos.x + 20, 
            top: tooltipPos.y - 40 
          }}
        >
          <div className="bg-white rounded-xl p-4 shadow-2xl border border-gray-100 min-w-[200px]">
            <div className="flex justify-between items-start mb-3">
              <div>
                <h4 className="font-bold text-gray-900">{hoveredNode.name}</h4>
                <p className="text-xs text-gray-400 font-bold uppercase tracking-widest">{hoveredNode.tier} Tier</p>
              </div>
              <div 
                className="px-2 py-1 rounded-lg text-xs font-bold"
                style={{ 
                  backgroundColor: hoveredNode.tier === 'Good' ? '#1D9E7520' : hoveredNode.tier === 'Fair' ? '#BA751720' : '#D85A3020',
                  color: hoveredNode.tier === 'Good' ? '#1D9E75' : hoveredNode.tier === 'Fair' ? '#BA7517' : '#D85A30'
                }}
              >
                {hoveredNode.score}
              </div>
            </div>
            
            <div className="flex items-center gap-2 mb-4">
              <Users className="w-3 h-3 text-gray-400" />
              <span className="text-xs text-gray-500 font-medium">{hoveredNode.vouchCount} vouches received</span>
            </div>

            <div className="w-full bg-gray-100 h-1 rounded-full overflow-hidden">
              <div 
                className="h-full transition-all duration-500" 
                style={{ 
                  width: `${((hoveredNode.score - 300) / (850 - 300)) * 100}%`,
                  backgroundColor: hoveredNode.tier === 'Good' ? '#1D9E75' : hoveredNode.tier === 'Fair' ? '#BA7517' : '#D85A30'
                }}
              ></div>
            </div>
          </div>
        </div>
      )}

      {/* Info Button */}
      <button className="absolute bottom-8 right-8 z-10 w-12 h-12 bg-white/10 hover:bg-white/20 backdrop-blur-md border border-white/10 rounded-full flex items-center justify-center text-white transition-all">
        <Info className="w-6 h-6" />
      </button>
    </div>
  );
}
