import React from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  Shield, 
  TrendingUp, 
  Users, 
  Plus, 
  MessageSquare, 
  ArrowUpRight,
  Info
} from 'lucide-react';
import { motion } from 'motion/react';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer, 
  Cell 
} from 'recharts';

const BREAKDOWN_DATA = [
  { name: 'Rent Payments', value: 145, positive: true },
  { name: 'Utility Bills', value: 92, positive: true },
  { name: 'Mobile Top-ups', value: 45, positive: true },
  { name: 'Peer Vouches', value: 120, positive: true },
  { name: 'Late Payments', value: -30, positive: false },
];

const VOUCHERS = [
  { name: 'Amara K.', score: 780, tier: 'Good', initials: 'AK' },
  { name: 'David O.', score: 620, tier: 'Fair', initials: 'DO' },
  { name: 'Chen W.', score: 810, tier: 'Good', initials: 'CW' },
  { name: 'Elena R.', score: 540, tier: 'Building', initials: 'ER' },
  { name: 'Kofi B.', score: 710, tier: 'Good', initials: 'KB' },
];

export default function Dashboard() {
  const navigate = useNavigate();
  const score = 742;
  const tier = 'Good';
  const scoreColor = '#1D9E75'; // Green for Good

  return (
    <div className="min-h-screen bg-[#F8F9FA] pb-12">
      {/* Navigation */}
      <nav className="bg-white border-b border-[#E5E7EB] px-6 py-4 sticky top-0 z-10">
        <div className="max-w-5xl mx-auto flex justify-between items-center">
          <div className="flex items-center gap-2 cursor-pointer" onClick={() => navigate('/')}>
            <Shield className="text-brand w-6 h-6" />
            <span className="text-xl font-bold tracking-tight">TrustChain</span>
          </div>
          <div className="flex items-center gap-6">
            <button 
              onClick={() => navigate('/network')}
              className="text-gray-600 font-medium hover:text-brand transition-colors"
            >
              Network
            </button>
            <div className="w-10 h-10 bg-brand/10 rounded-full flex items-center justify-center text-brand font-bold">
              JD
            </div>
          </div>
        </div>
      </nav>

      <main className="max-w-5xl mx-auto px-6 mt-8 space-y-6">
        {/* Hero Score Card */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="card flex flex-col items-center py-12"
        >
          <span className="text-sm font-bold text-gray-400 uppercase tracking-widest mb-4">Your Trust Score</span>
          <div className="relative flex items-center justify-center">
            <h1 className="text-[96px] font-bold leading-none" style={{ color: scoreColor }}>
              {score}
            </h1>
            {/* Subtle progress arc placeholder */}
            <div className="absolute -inset-8 border-4 border-gray-100 rounded-full border-t-brand rotate-45 opacity-20"></div>
          </div>
          <div className="mt-6 px-4 py-1 rounded-full bg-brand/10 text-brand font-bold text-sm uppercase tracking-wider">
            {tier} Tier
          </div>
          <div className="mt-8 w-full max-w-md bg-gray-100 h-1.5 rounded-full overflow-hidden">
            <div 
              className="h-full bg-brand transition-all duration-1000" 
              style={{ width: `${((score - 300) / (850 - 300)) * 100}%` }}
            ></div>
          </div>
          <div className="mt-2 w-full max-w-md flex justify-between text-[10px] font-bold text-gray-400 uppercase tracking-tighter">
            <span>300</span>
            <span>850</span>
          </div>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* AI Score Insights */}
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="card md:col-span-2 border-l-4"
            style={{ borderLeftColor: scoreColor }}
          >
            <div className="flex items-center gap-2 mb-4">
              <MessageSquare className="w-5 h-5 text-brand" />
              <h3 className="font-bold text-lg">AI Score Insights</h3>
            </div>
            <blockquote className="text-gray-700 text-lg leading-relaxed italic">
              "Your score increased by 12 points this month primarily due to consistent mobile top-ups and a new vouch from a high-trust node (Chen W.). Maintaining your utility payment streak will likely push you into the 'Excellent' tier within 60 days."
            </blockquote>
          </motion.div>

          {/* Quick Stats */}
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="card flex flex-col justify-center"
          >
            <div className="flex items-center gap-3 mb-2">
              <TrendingUp className="w-5 h-5 text-brand" />
              <span className="text-gray-500 font-medium">Monthly Growth</span>
            </div>
            <div className="text-3xl font-bold text-brand">+4.2%</div>
            <p className="text-sm text-gray-400 mt-2">Top 15% of your local network</p>
          </motion.div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Score Breakdown */}
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
            className="card"
          >
            <div className="flex justify-between items-center mb-8">
              <h3 className="font-bold text-lg">Score Breakdown</h3>
              <Info className="w-4 h-4 text-gray-300" />
            </div>
            <div className="h-[300px] w-full">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart
                  layout="vertical"
                  data={BREAKDOWN_DATA}
                  margin={{ top: 5, right: 30, left: 40, bottom: 5 }}
                >
                  <XAxis type="number" hide />
                  <YAxis 
                    dataKey="name" 
                    type="category" 
                    axisLine={false} 
                    tickLine={false}
                    width={100}
                    tick={{ fontSize: 12, fontWeight: 500, fill: '#6B7280' }}
                  />
                  <Tooltip 
                    cursor={{ fill: 'transparent' }}
                    contentStyle={{ borderRadius: '8px', border: 'none', boxShadow: '0 4px 12px rgba(0,0,0,0.1)' }}
                  />
                  <Bar dataKey="value" radius={[0, 4, 4, 0]} barSize={20}>
                    {BREAKDOWN_DATA.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.positive ? '#1D9E75' : '#D85A30'} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
          </motion.div>

          {/* My Vouchers */}
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
            className="card"
          >
            <div className="flex justify-between items-center mb-8">
              <h3 className="font-bold text-lg">My Vouchers</h3>
              <Users className="w-4 h-4 text-gray-300" />
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-6">
              {VOUCHERS.map((vouch, i) => (
                <div key={i} className="flex flex-col items-center text-center group cursor-pointer">
                  <div 
                    className="w-16 h-16 rounded-full flex items-center justify-center text-xl font-bold mb-3 transition-transform group-hover:scale-105"
                    style={{ 
                      backgroundColor: vouch.tier === 'Good' ? '#1D9E7520' : vouch.tier === 'Fair' ? '#BA751720' : '#D85A3020',
                      color: vouch.tier === 'Good' ? '#1D9E75' : vouch.tier === 'Fair' ? '#BA7517' : '#D85A30',
                      border: `2px solid ${vouch.tier === 'Good' ? '#1D9E75' : vouch.tier === 'Fair' ? '#BA7517' : '#D85A30'}`
                    }}
                  >
                    {vouch.initials}
                  </div>
                  <span className="font-bold text-sm text-gray-800">{vouch.name}</span>
                  <span className="text-xs text-gray-400 font-medium">{vouch.score} • {vouch.tier}</span>
                </div>
              ))}
              <button className="flex flex-col items-center justify-center border-2 border-dashed border-gray-200 rounded-xl p-4 hover:border-brand hover:bg-brand/5 transition-all group">
                <div className="w-10 h-10 rounded-full bg-gray-100 flex items-center justify-center mb-2 group-hover:bg-brand group-hover:text-white transition-colors">
                  <Plus className="w-6 h-6" />
                </div>
                <span className="text-xs font-bold text-gray-400 group-hover:text-brand">Add New</span>
              </button>
            </div>
          </motion.div>
        </div>

        {/* Action Buttons */}
        <div className="flex flex-col md:flex-row gap-4 pt-4">
          <button className="flex-1 btn-primary flex items-center justify-center gap-2">
            <Users className="w-5 h-5" />
            Vouch for Someone
          </button>
          <button className="flex-1 btn-secondary flex items-center justify-center gap-2">
            <Plus className="w-5 h-5" />
            Add Trust Signal
          </button>
        </div>
      </main>
    </div>
  );
}
